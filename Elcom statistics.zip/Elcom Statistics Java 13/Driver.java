/* "Elcom Statistics software"
Date: 30.06.2021
Created by: Andrea Palombi
IDE: IntelliJ
Description: This program accepts an .html or .xml file as input and produce the following statistics:
- Word count
- Line count
- Mean word length  */


//This class is the Driver class. It just runs the program.
public class Driver {

    public static void main(String[] args) {
        FileLoader fileLoader = new FileLoader();
    }

}
