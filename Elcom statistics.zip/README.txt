***This software has been created by Andrea Palombi for Elcom International, Inc. ***

The .zip folder contains a folder with the source solution (.java files). The "Elcom Statistics" software has been coded using 
Java 13 and IntelliJ IDE. 


To run this Java program:

1) Open the .zip file and unzip the folder
2) open Windows Command Prompt and type the folder path
3) compile java program using the following command: "javac Driver.java" 
4) Run the Java program typing the following command: "java Driver"


How to use "Elcom software":
1) Click on "Select File" button and select the .txt or .xml file from the choosen path
2) Click on "Count" button.